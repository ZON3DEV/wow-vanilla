﻿Imports System.IO
Imports System.Net
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblUSER.Text = Environment.UserName
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        If NsTabControl1.SelectedTab Is TabPage1 Then
            TextBox1.Text = "http://worldofwarcry.sytes.net:8091/wow/client/Classic/" & ListBox1.SelectedItem
            TextBox2.Text = "C:\Users\" & lblUSER.Text & "\Downloads\" & ListBox1.SelectedItem
        End If
    End Sub

    Private Sub Form1_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosing

    End Sub

    Private Sub ListBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox2.SelectedIndexChanged
        If NsTabControl1.SelectedTab Is TabPage2 Then
            TextBox1.Text = "http://worldofwarcry.sytes.net:8091/wow/client/WotLK/" & ListBox2.SelectedItem
            TextBox2.Text = "C:\Users\" & lblUSER.Text & "\Downloads\" & ListBox2.SelectedItem
        End If
    End Sub

    Private Sub ListBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox3.SelectedIndexChanged
        If NsTabControl1.SelectedTab Is TabPage3 Then
            TextBox1.Text = "http://worldofwarcry.sytes.net:8091/wow/Patches/4.0.1/" & ListBox3.SelectedItem
            TextBox2.Text = My.Settings.Downloads & ListBox3.SelectedItem
        End If
    End Sub

    Private Sub ListBox5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox5.SelectedIndexChanged
        If NsTabControl1.SelectedTab Is TabPage5 Then
            TextBox1.Text = "http://worldofwarcry.sytes.net:8098/" & ListBox5.SelectedItem
            TextBox2.Text = "C:\Users\" & lblUSER.Text & "\Downloads\" & ListBox5.SelectedItem
        End If
    End Sub

    Public WithEvents download As WebClient
    Private Sub ButtonBlue1_Click(sender As Object, e As EventArgs) Handles ButtonBlue1.Click
        Try
            download = New WebClient
            download.DownloadFileAsync(New Uri(TextBox1.Text), TextBox2.Text)
            ButtonBlue1.Enabled = False
        Catch ex As Exception
            MsgBox("Fehler! " & ex.Message)
        End Try
    End Sub

    Private Sub download_DownloadFileCompleted(sender As Object, e As System.ComponentModel.AsyncCompletedEventArgs) Handles download.DownloadFileCompleted
        Try
            ButtonBlue1.Enabled = True
            Label2.Text = "0%"
            Label1.Text = "0 MB | 0 MB"
            NsProgressBar1.Value = 0
        Catch ex As Exception

        End Try

    End Sub

    Private Sub download_DownloadProgressChanged(ByVal sender As System.Object, ByVal e As System.Net.DownloadProgressChangedEventArgs) Handles download.DownloadProgressChanged
        Dim totalbytes As Long = e.TotalBytesToReceive / 1024
        Dim mtotalbytes As Long = totalbytes / 1024
        Dim bytes As Long = e.BytesReceived / 1024
        Dim mbytes As Long = bytes / 1024
        If totalbytes < 1 Then totalbytes = 1
        If bytes < 1 Then bytes = 1
        If totalbytes > 1024 Then
            Label1.Text = mbytes.ToString & " MB von " & mtotalbytes & " MB"
        Else
            Label1.Text = bytes.ToString & " KB von " & totalbytes & " KB"
        End If
        NsProgressBar1.Value = e.ProgressPercentage
        Label2.Text = NsProgressBar1.Value & "%"
    End Sub

    Private Sub ButtonBlue2_Click(sender As Object, e As EventArgs) Handles ButtonBlue2.Click
        End
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        If FolderBrowserDialog1.ShowDialog = DialogResult.OK Then
            My.Settings.Downloads = FolderBrowserDialog1.SelectedPath & "\"
        End If
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Dim UpdateCheck As WebClient = New WebClient()
        Dim CurrentVersion = UpdateCheck.DownloadString("http://worldofwarcry.sytes.net/wow/launcher/version.ini")

        If CurrentVersion.Contains("1.0.0") Then
            Label6.Text = "Keine Updates verfügbar"
        Else
            Label6.Text = "Aktualisierungen werden bereit gestellt..."
            Dim Client As WebClient = New WebClient()
            Client.DownloadFile("http://worldofwarcry.sytes.net/wow/launcher/updates/Update.exe", "Update.exe")
            Client.DownloadFile("http://worldofwarcry.sytes.net/wow/launcher/version.ini", "version.ini")
        End If
    End Sub
End Class

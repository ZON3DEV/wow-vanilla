﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.NsTabControl1 = New WoW_Client_Downloader.NSTabControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblUSER = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.ListBox4 = New System.Windows.Forms.ListBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.NsGroupBox2 = New WoW_Client_Downloader.NSGroupBox()
        Me.ListBox5 = New System.Windows.Forms.ListBox()
        Me.NsGroupBox1 = New WoW_Client_Downloader.NSGroupBox()
        Me.NsProgressBar1 = New WoW_Client_Downloader.NSProgressBar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ButtonBlue1 = New WoW_Client_Downloader.ButtonBlue()
        Me.ButtonBlue2 = New WoW_Client_Downloader.ButtonBlue()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.NsTabControl1.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.NsGroupBox2.SuspendLayout()
        Me.NsGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'NsTabControl1
        '
        Me.NsTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.NsTabControl1.Controls.Add(Me.TabPage6)
        Me.NsTabControl1.Controls.Add(Me.TabPage1)
        Me.NsTabControl1.Controls.Add(Me.TabPage2)
        Me.NsTabControl1.Controls.Add(Me.TabPage3)
        Me.NsTabControl1.Controls.Add(Me.TabPage4)
        Me.NsTabControl1.Controls.Add(Me.TabPage5)
        Me.NsTabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed
        Me.NsTabControl1.ItemSize = New System.Drawing.Size(28, 115)
        Me.NsTabControl1.Location = New System.Drawing.Point(12, 12)
        Me.NsTabControl1.Multiline = True
        Me.NsTabControl1.Name = "NsTabControl1"
        Me.NsTabControl1.SelectedIndex = 0
        Me.NsTabControl1.Size = New System.Drawing.Size(548, 271)
        Me.NsTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.NsTabControl1.TabIndex = 0
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage6.Controls.Add(Me.Label6)
        Me.TabPage6.Controls.Add(Me.LinkLabel2)
        Me.TabPage6.Controls.Add(Me.LinkLabel1)
        Me.TabPage6.Controls.Add(Me.Label5)
        Me.TabPage6.Controls.Add(Me.lblUSER)
        Me.TabPage6.Controls.Add(Me.Label4)
        Me.TabPage6.Location = New System.Drawing.Point(119, 4)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(425, 263)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Informationen"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(23, 231)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 14)
        Me.Label6.TabIndex = 8
        '
        'LinkLabel2
        '
        Me.LinkLabel2.ActiveLinkColor = System.Drawing.Color.DeepSkyBlue
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.DisabledLinkColor = System.Drawing.Color.DeepSkyBlue
        Me.LinkLabel2.ForeColor = System.Drawing.Color.SkyBlue
        Me.LinkLabel2.LinkColor = System.Drawing.Color.DeepSkyBlue
        Me.LinkLabel2.Location = New System.Drawing.Point(291, 231)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(115, 14)
        Me.LinkLabel2.TabIndex = 7
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Auf Updates Prüfen"
        Me.LinkLabel2.Visible = False
        Me.LinkLabel2.VisitedLinkColor = System.Drawing.Color.DeepSkyBlue
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.DeepSkyBlue
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabel1.DisabledLinkColor = System.Drawing.Color.DeepSkyBlue
        Me.LinkLabel1.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.LinkLabel1.LinkColor = System.Drawing.Color.DeepSkyBlue
        Me.LinkLabel1.Location = New System.Drawing.Point(320, 89)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(33, 14)
        Me.LinkLabel1.TabIndex = 6
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "HIER"
        Me.LinkLabel1.VisitedLinkColor = System.Drawing.Color.DeepSkyBlue
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Gray
        Me.Label5.Location = New System.Drawing.Point(23, 60)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(383, 56)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = resources.GetString("Label5.Text")
        '
        'lblUSER
        '
        Me.lblUSER.AutoSize = True
        Me.lblUSER.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUSER.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.lblUSER.Location = New System.Drawing.Point(121, 22)
        Me.lblUSER.Name = "lblUSER"
        Me.lblUSER.Size = New System.Drawing.Size(81, 16)
        Me.lblUSER.TabIndex = 4
        Me.lblUSER.Text = "Current User"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(23, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 16)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Angemeldet als:"
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.ListBox1)
        Me.TabPage1.Location = New System.Drawing.Point(119, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(425, 263)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Client 1.12.1"
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.Black
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox1.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 14
        Me.ListBox1.Items.AddRange(New Object() {"Vanilla 1.12.1 5875 (enGB).zip", "Drums of War Setup.part1.exe", "Drums of War Setup.part2.rar", "Drums of War Setup.part3.rar", "Drums of War Setup.part4.rar", "Drums of War Setup.part5.rar"})
        Me.ListBox1.Location = New System.Drawing.Point(6, 6)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(413, 252)
        Me.ListBox1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.ListBox2)
        Me.TabPage2.Location = New System.Drawing.Point(119, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(425, 263)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Client 3.3.5a"
        '
        'ListBox2
        '
        Me.ListBox2.BackColor = System.Drawing.Color.Black
        Me.ListBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox2.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 14
        Me.ListBox2.Items.AddRange(New Object() {"WotLK_3.3.5.part01.exe", "WotLK_3.3.5.part02.rar", "WotLK_3.3.5.part03.rar", "WotLK_3.3.5.part04.rar", "WotLK_3.3.5.part05.rar", "WotLK_3.3.5.part06.rar", "WotLK_3.3.5.part07.rar", "WotLK_3.3.5.part08.rar", "WotLK_3.3.5.part09.rar", "WotLK_3.3.5.part10.rar", "WotLK_3.3.5.part11.rar", "WotLK_3.3.5.part12.rar", "WotLK_3.3.5.part13.rar", "WotLK_3.3.5.part14.rar", "WotLK_3.3.5.part15.rar", "WotLK_3.3.5.part16.rar", "WotLK_3.3.5.part17.rar", "WotLK_3.3.5.part18.rar", "WotLK_3.3.5.part19.rar"})
        Me.ListBox2.Location = New System.Drawing.Point(6, 5)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(413, 252)
        Me.ListBox2.TabIndex = 1
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.ListBox3)
        Me.TabPage3.Location = New System.Drawing.Point(119, 4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(425, 263)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Patch 4.0.1"
        '
        'ListBox3
        '
        Me.ListBox3.BackColor = System.Drawing.Color.Black
        Me.ListBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox3.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.ItemHeight = 14
        Me.ListBox3.Items.AddRange(New Object() {"WoW-3.3.0.10958-4.0.0.12911-EU-Stage-1.zip", "WoW-3.3.0.10958-4.0.0.12911-EU-Stage-2.zip", "WoW-3.3.0.10958-4.0.0.12911-EU-Stage-3.zip", "WoW-x.x.x.x-4.0.0.12911-Installer.EU.zip"})
        Me.ListBox3.Location = New System.Drawing.Point(6, 5)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(413, 252)
        Me.ListBox3.TabIndex = 1
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.ListBox4)
        Me.TabPage4.Location = New System.Drawing.Point(119, 4)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(425, 263)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Patch 1.12"
        '
        'ListBox4
        '
        Me.ListBox4.BackColor = System.Drawing.Color.Black
        Me.ListBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox4.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.ListBox4.FormattingEnabled = True
        Me.ListBox4.ItemHeight = 14
        Me.ListBox4.Location = New System.Drawing.Point(6, 5)
        Me.ListBox4.Name = "ListBox4"
        Me.ListBox4.Size = New System.Drawing.Size(413, 252)
        Me.ListBox4.TabIndex = 1
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage5.Controls.Add(Me.Label7)
        Me.TabPage5.Controls.Add(Me.NsGroupBox2)
        Me.TabPage5.Location = New System.Drawing.Point(119, 4)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(425, 263)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Sonstiges"
        '
        'NsGroupBox2
        '
        Me.NsGroupBox2.Controls.Add(Me.ListBox5)
        Me.NsGroupBox2.DrawSeperator = False
        Me.NsGroupBox2.Location = New System.Drawing.Point(23, 50)
        Me.NsGroupBox2.Name = "NsGroupBox2"
        Me.NsGroupBox2.Size = New System.Drawing.Size(129, 77)
        Me.NsGroupBox2.SubTitle = ""
        Me.NsGroupBox2.TabIndex = 0
        Me.NsGroupBox2.Text = "NsGroupBox2"
        Me.NsGroupBox2.Title = ""
        '
        'ListBox5
        '
        Me.ListBox5.BackColor = System.Drawing.Color.Black
        Me.ListBox5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox5.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.ListBox5.FormattingEnabled = True
        Me.ListBox5.ItemHeight = 14
        Me.ListBox5.Items.AddRange(New Object() {"dbc.7z", "maps.7z", "vmaps.7z", "mmaps.7z"})
        Me.ListBox5.Location = New System.Drawing.Point(3, 3)
        Me.ListBox5.Name = "ListBox5"
        Me.ListBox5.Size = New System.Drawing.Size(122, 70)
        Me.ListBox5.TabIndex = 1
        '
        'NsGroupBox1
        '
        Me.NsGroupBox1.Controls.Add(Me.NsProgressBar1)
        Me.NsGroupBox1.Controls.Add(Me.Label3)
        Me.NsGroupBox1.Controls.Add(Me.Label2)
        Me.NsGroupBox1.Controls.Add(Me.Label1)
        Me.NsGroupBox1.DrawSeperator = False
        Me.NsGroupBox1.Location = New System.Drawing.Point(12, 299)
        Me.NsGroupBox1.Name = "NsGroupBox1"
        Me.NsGroupBox1.Size = New System.Drawing.Size(428, 109)
        Me.NsGroupBox1.SubTitle = ""
        Me.NsGroupBox1.TabIndex = 1
        Me.NsGroupBox1.Text = "NsGroupBox1"
        Me.NsGroupBox1.Title = ""
        '
        'NsProgressBar1
        '
        Me.NsProgressBar1.Location = New System.Drawing.Point(21, 43)
        Me.NsProgressBar1.Maximum = 100
        Me.NsProgressBar1.Minimum = 0
        Me.NsProgressBar1.Name = "NsProgressBar1"
        Me.NsProgressBar1.Size = New System.Drawing.Size(387, 22)
        Me.NsProgressBar1.TabIndex = 3
        Me.NsProgressBar1.Text = "NsProgressBar1"
        Me.NsProgressBar1.Value = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(18, 19)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 16)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Fortschritt:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label2.Location = New System.Drawing.Point(85, 19)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(27, 16)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "0%"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label1.Location = New System.Drawing.Point(18, 75)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "0 MB | 0 MB"
        '
        'ButtonBlue1
        '
        Me.ButtonBlue1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonBlue1.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.ButtonBlue1.Image = Nothing
        Me.ButtonBlue1.Location = New System.Drawing.Point(456, 299)
        Me.ButtonBlue1.Name = "ButtonBlue1"
        Me.ButtonBlue1.NoRounding = False
        Me.ButtonBlue1.Size = New System.Drawing.Size(104, 65)
        Me.ButtonBlue1.TabIndex = 2
        Me.ButtonBlue1.Text = "Download"
        '
        'ButtonBlue2
        '
        Me.ButtonBlue2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ButtonBlue2.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.ButtonBlue2.Image = Nothing
        Me.ButtonBlue2.Location = New System.Drawing.Point(456, 370)
        Me.ButtonBlue2.Name = "ButtonBlue2"
        Me.ButtonBlue2.NoRounding = False
        Me.ButtonBlue2.Size = New System.Drawing.Size(104, 38)
        Me.ButtonBlue2.TabIndex = 3
        Me.ButtonBlue2.Text = "Beenden"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(559, 414)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(12, 22)
        Me.TextBox1.TabIndex = 4
        Me.TextBox1.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(559, 414)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(12, 22)
        Me.TextBox2.TabIndex = 5
        Me.TextBox2.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(20, 21)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(169, 14)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Client Data für MaNGOS Zero:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(55, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(572, 430)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ButtonBlue2)
        Me.Controls.Add(Me.ButtonBlue1)
        Me.Controls.Add(Me.NsGroupBox1)
        Me.Controls.Add(Me.NsTabControl1)
        Me.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Silver
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "World of Warcraft | Client Downloader"
        Me.NsTabControl1.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.NsGroupBox2.ResumeLayout(False)
        Me.NsGroupBox1.ResumeLayout(False)
        Me.NsGroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents NsTabControl1 As NSTabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents ListBox3 As ListBox
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents ListBox4 As ListBox
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents NsGroupBox1 As NSGroupBox
    Friend WithEvents NsProgressBar1 As NSProgressBar
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ButtonBlue1 As ButtonBlue
    Friend WithEvents ButtonBlue2 As ButtonBlue
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents lblUSER As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Label5 As Label
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents Label6 As Label
    Friend WithEvents NsGroupBox2 As NSGroupBox
    Friend WithEvents ListBox5 As ListBox
    Friend WithEvents Label7 As Label
End Class
